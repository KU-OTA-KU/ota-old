<section class="anime-stills">
  <div class="anime-stills-inner">
    <div class="anime-stills-tit">
      <div class="anime-stills-title">
        <h2>Кадры</h2>
        <h6>Топ Кадры из Аниме</h6>
      </div>
      </div>
      <div class="anime-stills-container">
        <div class="anime-stills-content"></div>
        <div class="anime-stills-content"></div>
        <div class="anime-stills-content"></div>
        <div class="anime-stills-content"></div>
      </div>
    </div>
  </div>
</section>