<section class="animes-related">
    <div class="animes-related-inner">
        <div class="animes-related-tit">
            <div class="related-animes-list-title">
                <h2>Связенное</h2>
                <h6>Связенные с франшизой сериалы, фильмы</h6>
            </div>
            <div class="related-animes-container">
              <div class="related-animes-block">
                <div class="related-animes-name">
                  <a href=""></a>
                </div>
                <div class="related-animes-info">
                  <div class="related-animes-info-image">
                  </div>
                  <div class="related-animes-type-year">
                    <p></p>
                    <p></p>
                  </div>
                </div>
              </div>
            </div>
        </div>
    </div>
</section>