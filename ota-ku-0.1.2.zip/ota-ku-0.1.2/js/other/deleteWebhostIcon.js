document.addEventListener('DOMContentLoaded', () =>{
  var dis = document.querySelector("img[alt='www.000webhost.com']");
  if(dis){
      dis.remove();
  }
});

//  apri tikon