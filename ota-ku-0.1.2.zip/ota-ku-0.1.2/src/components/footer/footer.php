<footer>
    <div class="footer-inner-container">
        <div class="footer-inner-tit" id="wdwdwdtit">
            <div class="footer-one-container">
                <div class="footer-logo">
                    <img src="<?php echo 'http://' . $_SERVER['HTTP_HOST']; ?>/assets/images/ota-ku.png" alt="animeCo">
                    <p>Весь контент на сайте предназначен исключительно для личного ознакомления. Мы используем
                        материалы из
                        свободных источников. Если какой-то контент нарушает ваши авторские права, пожалуйста, свяжитесь
                        с
                        нами, и мы незамедлительно удалим его. Однако мы не можем гарантировать, что он не будет
                        загружен на
                        сайт снова другими пользователями. Копирование материала с сайта разрешено только после
                        получения
                        разрешения администрации. Сайт предназначен для лиц старше 16+ лет.</p>
                </div>
                <div class="footer-other">
                    <div class="documents">
                        <h3>Документы</h3>
                        <ul>
                            <li><a href="#">Политика конфиденциальности</a></li>
                            <li><a href="<?php echo 'http://' . $_SERVER['HTTP_HOST']; ?>/doc/terms_ru.php">Пользовательское
                                    соглашение</a></li>
                            <li><a href="<?php echo 'http://' . $_SERVER['HTTP_HOST']; ?>/doc/authors_ru.php">Правообладатели</a>
                            </li>
                            <!-- <li><a href="#">Правила сайта</a></li>-->
                        </ul>
                    </div>
                    <div class="contacts">
                        <h3>Контакты</h3>
                        <ul>
                            <li>Email: <span>w33bv.gl@gmail.com</span></li>
                            <li>Телефон: <span>+374(94)161-331<span></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="footer-copyright">
                <p>© 2023-2024 オタ-KU OTA-KU Все права защищены. Сайт <a href="https://ota-ku.ru/">Ota-ku.ru</a></p>
            </div>
        </div>
    </div>
</footer>
