<section class="most-container">
  <div class="most-container-inner">
    <div class="most-container-tit">
      <div class="most-content-gallery-cell">
        <div class="most-content-title-h2">
          <h2>Онгоинги</h2>
        </div>
        <div class="most-content-animes-list-option-1">
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="most-content-gallery-cell">
        <div class="most-content-title-h2">
          <h2>Анонсы</h2>
        </div>
        <div class="most-content-animes-list-option-2">
        <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="most-content-gallery-cell">
        <div class="most-content-title-h2">
          <h2>Топ аниме</h2>
        </div>
        <div class="most-content-animes-list-option-3">
        <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
        </div>
      </div>
      <div class="most-content-gallery-cell">
        <div class="most-content-title-h2">
          <h2>Завершенные</h2>
        </div>
        <div class="most-content-animes-list-option-4">
        <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
          <div class="most-content-movie">
            <div class="most-content-movie-image"></div>
            <div class="most-content-movie-info">
              <div class="most-name"></div>
              <div class="most-status">
                <div class="most-type"></div>
                <div class="rating"></div>
              </div>
              <div class="most-data"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>