<section class="anime-description">
    <div class="anime-description-inner">
        <div class="anime-description-tit">
            <p></p>
        </div>
    </div>
</section>