<section class="all-genres">
    <div class="all-genres-list-inner">
        <div class="all-genres-list-tit">
            <div class="all-genres-list-container">
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=5'">
                    <h3>Авангард</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=543'">
                    <h3>Гурман</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=8'">
                    <h3>Драмма</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=4'">
                    <h3>Комедия</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=36'">
                    <h3>Повседневность</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=2'">
                    <h3>Приключения</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=22'">
                    <h3>Романтика</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=37'">
                    <h3>Сверхъестественное</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=30'">
                    <h3>Спорт</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=7'">
                    <h3>Тайна</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=117'">
                    <h3>Триллер</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=14'">
                    <h3>Ужасы</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=24'">
                    <h3>Фантастика</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=10'">
                    <h3>Фэнтези</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=1'">
                    <h3>Экшен</h3>
                </div>
                <div class="genre-cont" onclick="window.location.href = 'catalog.php?genres=9'">
                    <h3>Этти</h3>
                </div>
                <!-- <div class="genre-cont"  onclick="window.location.href = 'catalog.php?genres=539'">
                  <h3>Эротика</h3>
                </div> -->
                <!-- <div class="genre-cont"  onclick="window.location.href = 'catalog.php?genres=12'">
                  <h3>Хентай</h3>
                </div> -->
            </div>
        </div>
    </div>
</section>