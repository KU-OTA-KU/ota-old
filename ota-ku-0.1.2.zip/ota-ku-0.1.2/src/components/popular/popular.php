<section class="top-popular-animes">
    <div class="top-popular-animes-inner">
        <div class="top-popular-animes-tit">
            <div class="top-popular-animes-title-h2">
                <h2>Популярное</h2>
                <h6>Самые популярные произведения в <?php echo date('Y'); ?></h6>
            </div>
            <div class="top-popular-animes-content">
                <div class="movie">
                    <div class="movie-image">
                    </div>
                    <div class="movie-name">
                        <div class="status">
                            <div class="type"></div>
                            <div class="rating">
                            </div>
                        </div>
                        <div class="name">
                            <a href="#"></a>
                        </div>
                    </div>
                </div>
                <div class="movie">
                    <div class="movie-image">
                    </div>
                    <div class="movie-name">
                        <div class="status">
                            <div class="type"></div>
                            <div class="rating">
                            </div>
                        </div>
                        <div class="name">
                            <a href="#"></a>
                        </div>
                    </div>
                </div>
                <div class="movie">
                    <div class="movie-image">
                    </div>
                    <div class="movie-name">
                        <div class="status">
                            <div class="type"></div>
                            <div class="rating">
                            </div>
                        </div>
                        <div class="name">
                            <a href="#"></a>
                        </div>
                    </div>
                </div>
                <div class="movie">
                    <div class="movie-image">
                    </div>
                    <div class="movie-name">
                        <div class="status">
                            <div class="type"></div>
                            <div class="rating">
                            </div>
                        </div>
                        <div class="name">
                            <a href="#"></a>
                        </div>
                    </div>
                </div>
                <div class="movie">
                    <div class="movie-image">
                    </div>
                    <div class="movie-name">
                        <div class="status">
                            <div class="type"></div>
                            <div class="rating">
                            </div>
                        </div>
                        <div class="name">
                            <a href="#"></a>
                        </div>
                    </div>
                </div>
                <div class="movie">
                    <div class="movie-image">
                    </div>
                    <div class="movie-name">
                        <div class="status">
                            <div class="type"></div>
                            <div class="rating">
                            </div>
                        </div>
                        <div class="name">
                            <a href="#"></a>
                        </div>
                    </div>
                </div>
                <div class="movie">
                    <div class="movie-image">
                    </div>
                    <div class="movie-name">
                        <div class="status">
                            <div class="type"></div>
                            <div class="rating">
                            </div>
                        </div>
                        <div class="name">
                            <a href="#"></a>
                        </div>
                    </div>
                </div>
                <div class="movie">
                    <div class="movie-image">
                    </div>
                    <div class="movie-name">
                        <div class="status">
                            <div class="type"></div>
                            <div class="rating">
                            </div>
                        </div>
                        <div class="name">
                            <a href="#"></a>
                        </div>
                    </div>
                </div>
                <div class="movie">
                    <div class="movie-image">
                    </div>
                    <div class="movie-name">
                        <div class="status">
                            <div class="type"></div>
                            <div class="rating">
                            </div>
                        </div>
                        <div class="name">
                            <a href="#"></a>
                        </div>
                    </div>
                </div>
                <div class="movie">
                    <div class="movie-image">
                    </div>
                    <div class="movie-name">
                        <div class="status">
                            <div class="type"></div>
                            <div class="rating">
                            </div>
                        </div>
                        <div class="name">
                            <a href="#"></a>
                        </div>
                    </div>
                </div>
                <div class="movie">
                    <div class="movie-image">
                    </div>
                    <div class="movie-name">
                        <div class="status">
                            <div class="type"></div>
                            <div class="rating">
                            </div>
                        </div>
                        <div class="name">
                            <a href="#"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>