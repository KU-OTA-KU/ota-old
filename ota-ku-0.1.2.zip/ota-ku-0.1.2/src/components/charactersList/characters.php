<section class="characters-list">
    <div class="characters-list-inner">
        <div class="characters-list-tit">
            <div class="characters-list-title">
                <h2>Персонажи</h2>
                <h6>Главные герои и персонажи из аниме</h6>
            </div>
            <div class="characters-list-container">
                <div class="character-content">
                    <div class="character-content-image"></div>
                    <p></p>
                </div>
            </div>
        </div>
    </div>
</section>