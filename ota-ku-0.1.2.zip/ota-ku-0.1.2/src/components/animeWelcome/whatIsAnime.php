<section class="what-is-anime-container">
    <div class="what-is-anime-container-inner">
        <div class="what-is-anime-container-tit">
            <div class="what-is-anime-main">
                <h1><a href="https://ota-ku.ru">オタ-KU</a> – лучший портал для любителей аниме!</h1>
                <div class="what-is-cont-1">
                    <p><strong>Аниме</strong> – это не просто анимация из Японии, это волшебный мир, где реальность
                        переплетается с фантазией, а обыденное становится необыкновенным! Здесь ты можешь отправиться в
                        захватывающее путешествие по разным жанрам, от веселых комедий до захватывающих приключений и
                        драматических историй. Аниме способно поразить своим разнообразием и глубиной, оставляя
                        незабываемый след в сердцах своих зрителей. Каждая история - это уникальное приключение, полное
                        эмоций и вдохновения, готовое погрузить тебя в фантастический мир возможностей и неожиданных
                        поворотов!</p>
                </div>
                <div class="what-is-cont-2">
                    <p><strong>Ота-ку</strong> (от японского слова <strong>"отаку" "オタク"</strong>.) – это не просто
                        термин, это страсть и преданность миру аниме и манги! Наш сайт одаёт дань этому увлечению и
                        предлагаем насладиться разнообразным контентом. Мы собрали лучшие произведения этого жанра,
                        чтобы каждый посетитель мог найти что-то особенное для себя. Наши страницы наполнены яркими
                        эмоциями и захватывающими приключениями. Присоединяйся к нам и погрузись в волшебный мир
                        японской анимации прямо сейчас!</p>
                </div>
                <div class="what-is-anime-social">
                    <div class="what-is-anime-social-item">
                        <b>Мы в соц Сетях: </b>
                    </div>
                    <div class="what-is-anime-social-item">
                        <a href="https://www.youtube.com/channel/UC4W8zn36O0oZwgzE_UnV7ng" target="_blank"><i class="fa-brands fa-youtube"></i></a>
                    </div>
                    <div class="what-is-anime-social-item">
                        <a href="https://t.me/+JixEqAyK48UwY2Vi" target="_blank"><i class="fa-brands fa-telegram"></i></a>
                    </div>
                </div>
            </div>
            <div class="what-is-anime-other">
                <img src="<?php 'https://' . $_SERVER['HTTP_HOST'] ?>assets/images/gas-kvas-com-p-anime-tyana-na-prozrachnom-fone-16.png"
                     alt="главная аниме тян в ota-ku.ru">
            </div>

        </div>
    </div>
</section>