<section class="player" name="watch">
    <div class="player-inner">
        <div class="player-tit">
            <div class="player-container">
                <div id="kodik-player"></div>
            </div>
<!--            <div class="player-right-panel">-->
<!--                <div class="ozvucka-or-player">-->
<!--                    <button id="is-on"><i class="fa-solid fa-film"></i>Серии</button>-->
<!--                    <button id="is-off"><i class="fa-solid fa-microphone"></i>Озвучка</button>-->
<!--                </div>-->
<!--                <div class="player-right-panel-content" id="voices">-->
<!--                    <a href="javascript:void(0)">Kodik</a>-->
<!--                </div>-->
<!--            </div>-->
        </div>
    </div>
</section>